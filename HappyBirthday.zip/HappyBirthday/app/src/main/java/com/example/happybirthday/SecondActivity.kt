package com.example.happybirthday


import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_second.*
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class SecondActivity : AppCompatActivity() {

    private lateinit var allTransaction: List<Transaction>
    private lateinit var transactionAdapter: TransactionAdapter
    private lateinit var linearLayoutManager: LinearLayoutManager
    private lateinit var database:AppDatabase
    private lateinit var deletedTransaction: Transaction
    private lateinit var oldTransaction: List<Transaction>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

//first we need to initialize the name that has been passed from the main activity
        val name1 = intent.getStringExtra("EXTRA_MESSAGE")
        //when the message is received I'm sending it to the textView
        val textView = findViewById<TextView>(R.id.welcomeUser).apply { text = "Hello "+ name1 }


        //two variables created to store the two fragments created
        val homeFragment = HomeFragment()
        val settingsFragment = SettingsFragment()
        //stores the homeFragment to be the one loaded first
        makeCurrentFragment(homeFragment)
        //when pressed the user gets prompted to a different fragment depeding on the item clicked


        bottom_navigation.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.ic_home -> makeCurrentFragment(homeFragment)
                R.id.ic_settings -> makeCurrentFragment(settingsFragment)
            }
            true
        }

        allTransaction = arrayListOf()


        transactionAdapter = TransactionAdapter(allTransaction)
        linearLayoutManager = LinearLayoutManager(this)

        database=Room.databaseBuilder(this,
        AppDatabase::class.java,
        "transactions").build()

        val recyclerview = findViewById<RecyclerView>(R.id.recyclerview)

        recyclerview.apply {
            adapter = transactionAdapter
            layoutManager = linearLayoutManager
        }

        //this will handle swipes
        val touchHelper = object :ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                return false
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                deleteTransaction(allTransaction[viewHolder.adapterPosition])
            }

        }

        val swipeHelper = ItemTouchHelper(touchHelper)
        swipeHelper.attachToRecyclerView(recyclerview)

        //this will prompt the user to the third screen
        val thirdActivityButton : Button = findViewById(R.id.addButton)
        thirdActivityButton.setOnClickListener {
            val Intent = Intent(this,plusTransactionActivity::class.java)
            startActivity(Intent)
        }

    }


    private fun fetchAll(){
    GlobalScope.launch {


        allTransaction = database.userDao().getAll()

        runOnUiThread {
            updateTotalSpent()
            transactionAdapter.updater(allTransaction)
        }
    }
    }
    private fun updateTotalSpent(){
        val total = allTransaction.map { it.amount }.sum()

        val totalSpent = findViewById<TextView>(R.id.totalSpent)
        totalSpent.text = "$ %.2f".format(total)
    }

    override fun onResume() {
        super.onResume()
        fetchAll()
    }
//function to trigger our custom menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.delete_menu,menu)
        return true
    }
//when our menu delete button gets pressed it triggers the deleteTran function that will build a pop up window and delete the whole database
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId == R.id.menu_delete){
            deleteTran()
        }
        return super.onOptionsItemSelected(item)
    }
    private fun deleteTran(){

        //builder is used to produce a pup up windown on the screen
        val builder = AlertDialog.Builder(this)
        builder.setPositiveButton("Yes"){ _, _ ->
            Toast.makeText(applicationContext,
                "All transactions cleared successfully", Toast.LENGTH_LONG).show()
            val  database=Room.databaseBuilder(this,
                AppDatabase::class.java,
                "transactions").build()
            //if user pressess yes we will be using the function deleteAll to delete every single transaction instead of only one (with delete function)
            GlobalScope.launch {
                database.userDao().deleteAll()

            }
            //this will be triggered to prompt user back to the main screen
            finish()



        }
        builder.setNegativeButton("No"){ _, _ ->}
        builder.setTitle("Are you sure you want do delete all the transactions?")
        builder.setMessage("Please confirm")
        builder.create().show()
    }
    //undo delete function re-inserts the deleted transaction type transaction that has been stored into the database and then refreshes the total spent
    private fun undoDelete(){
        GlobalScope.launch {
            database.userDao().insertAll(deletedTransaction)
            allTransaction = oldTransaction
            runOnUiThread {
                transactionAdapter.updater(allTransaction)
                updateTotalSpent()
            }
        }
    }

    private fun createBar(){
        val view = findViewById<View>(R.id.coordinatorLayout)
        //the bar used the function snackbar that creates this little bar in the very bottom of the screen
        val bar = Snackbar.make(view,"Transaction Deleted",Snackbar.LENGTH_LONG)
        bar.setAction("Undo"){
            //if the user happens to click on the bar action button we created the undoDelete function gets triggered
            undoDelete()
        }

            .setActionTextColor(ContextCompat.getColor(this,R.color.red))
            .show()

    }
//this method is used to delete transactions
    private fun deleteTransaction(transaction: Transaction){
       //first I stored the current transaction in a variable to be able to undo
        deletedTransaction = transaction
        oldTransaction = allTransaction

        //we use the delete from userDao to delete the transaction that is passed to the method
        GlobalScope.launch {
            database.userDao().delete(transaction)
            //once the transaction is deleted we need to refresh the total
            allTransaction = allTransaction.filter { it.id != transaction.id}
            runOnUiThread {
                //we use the update this function to refresh the total and refresh the total spent number on the top
                updateTotalSpent()
                transactionAdapter.updater(allTransaction)
                //to be able to undo de the deletion we create the bar
                createBar()
            }
        }
    }

//method created to replace the frame layout id fl_wrapper by the fragment that is selected
    private fun makeCurrentFragment(fragment: Fragment) =
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fl_wrapper, fragment)
            commit()
        }


}
