package com.example.happybirthday

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*


public class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonPickName : Button = findViewById(R.id.buttonName)
        val buttonNext:Button = findViewById(R.id.buttonNext)

        buttonPickName.setOnClickListener {
            Toast.makeText(this,"Name inserted successfully",Toast.LENGTH_SHORT).show()
            val name:EditText = findViewById(R.id.name)
            val getName: TextView = findViewById(R.id.textviewNameDisplay)

            // variable str is receiving the content of the edittext
           var str:String = name.text.toString()
            //putting variable into textview
            getName.setText(str)
            buttonNext.setVisibility(View.VISIBLE)


        }
        //fuction to be called when button for second activity is pressed
        fun callActivity(){
            val editText = findViewById<EditText>(R.id.name)
            val message = editText.text.toString()
            // the text that was input in the editText is stored inside of a variable called message and it's transmitted to the next activity as name "EXTRA_MESSAGE"
            val intent = Intent(this, SecondActivity::class.java).also {
                it.putExtra("EXTRA_MESSAGE",message)
                startActivity(it)
            }
        }

        val editText = findViewById<EditText>(R.id.name)
      val namee = editText.text.toString()
        //function to call the next activity
        val secondActivityButton : Button = findViewById(R.id.buttonNext)
        secondActivityButton.setOnClickListener {
            callActivity()
        }

    }

}