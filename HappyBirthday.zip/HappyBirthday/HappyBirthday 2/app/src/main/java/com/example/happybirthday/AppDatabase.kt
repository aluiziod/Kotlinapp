package com.example.happybirthday

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
//this is the last requirement for the Room Database, this is the database
//it handles an array of objects type Transaction (entity class)
@Database(entities = arrayOf(Transaction::class), version = 1)
//converters class has been created to handle the convertion of the picture(bitmap type) to and from byte array
@TypeConverters(Converters::class)
abstract class AppDatabase:RoomDatabase(){
    abstract fun userDao():transactionDao



}