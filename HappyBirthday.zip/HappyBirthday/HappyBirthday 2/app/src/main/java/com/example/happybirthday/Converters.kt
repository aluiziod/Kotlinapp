package com.example.happybirthday

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.room.TypeConverter
import java.io.ByteArrayOutputStream

class Converters {
//allows us to store custom type objects into the database
    // the database only accepts String, Int, Float and Long
    //this converts the type object from bitmap to ByteArray
    @TypeConverter
    fun fromBitmap (bitmap: Bitmap) : ByteArray {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        return outputStream.toByteArray()
    }
    //this converts the type object from ByteArray to Bitmap
    @TypeConverter
    fun toBitmap (byteArray: ByteArray): Bitmap {
        return BitmapFactory.decodeByteArray(byteArray, 0 ,byteArray.size)
    }
}