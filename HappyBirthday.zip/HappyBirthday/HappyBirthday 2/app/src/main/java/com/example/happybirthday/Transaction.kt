package com.example.happybirthday

import android.graphics.Bitmap
import androidx.room.Entity
import androidx.room.PrimaryKey
//this is the de data entity being used in the room database
@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int,
    val label: String,
    val amount: Double,
    val receipt: Bitmap? = null
    ) {


    }