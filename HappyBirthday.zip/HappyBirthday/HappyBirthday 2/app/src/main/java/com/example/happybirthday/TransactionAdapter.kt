package com.example.happybirthday

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_update.view.*

//this class extends the recyclerview adapter
class TransactionAdapter(private var transactions: List<Transaction>):
    RecyclerView.Adapter<TransactionAdapter.TransactionHolder>() {

    class  TransactionHolder(view:View) : RecyclerView.ViewHolder(view){
        val label : TextView = view.findViewById(R.id.label)
        val amount : TextView = view.findViewById(R.id.amount)
        val receipt : ImageView = view.findViewById(R.id.receipt)
    }
    //theh viewholder needs to be override. the parent will receive the ViewHolder we just created above
    //and it will inflate the layout with transaction_layout.xml that I created with all the texts and the imageview
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.transaction_layout,parent,false)
        return TransactionHolder(view)
    }
    //receives the transaction holder created above as one of the parameters
    override fun onBindViewHolder(holder: TransactionHolder, position: Int) {
        //we first get the transaction at the current position
        val transaction : Transaction = transactions[position]
        val context : Context = holder.amount.context
        //storing its content for each of the textviews and imageview
        holder.amount.text = "- €%.2f".format(transaction.amount)
        holder.label.text = transaction.label
        holder.receipt.setImageBitmap(transaction.receipt)

        //this is necessary to pass all the information from one activity to another when the card gets clicked
        holder.itemView.setOnClickListener{
            val intent = Intent(context, updateActivity::class.java)
            intent.putExtra("amount", transaction.amount)
            intent.putExtra("label",transaction.label)
            intent.putExtra("receipt",transaction.receipt)
            intent.putExtra("id",transaction.id)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return transactions.size
    }
    fun updater(transactions: List<Transaction>){
        this.transactions = transactions
        notifyDataSetChanged()
    }


}

